<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProformaCalculation extends Model
{
     protected $guarded =[];
}
