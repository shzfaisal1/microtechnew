@extends('master')

@section('main')
  <div class="search-client-info">
                            <div class="row">
							    <div class="col-lg-12 col-md-12">
							    	<div class="card">
							    		<div class="card-body">
                                            <div class="row">
                                            	<div class="col">
                                                	<div class="form-group">
                                                	    <label for="uname">Company Name <span class="text-danger">*</span> :</label>
                                                	    <div class="input-group mb-3 flex-nowrap">
                                                	        <select class="form-control select2-show-search" id="company_id" name="company_id" data-placeholder="Choose one (with searchbox)">
																<optgroup >
    
																	@if(!empty($companies))
																	@foreach ($companies as $company)
																	<option value="{{ $company->id }}">{{ $company->company_name }}</option>	
																	@endforeach
																	
																	@endif
																</optgroup>
															</select>
                                                	        <div class="input-group-append">
                                                	            <a href="{{url('company-details')}}" class="btn btn-light" type="submit"><i class="fa fa-plus text-success"></i></a>
                                                	        </div>
                                                	    </div>
                                                	</div>
                                            	</div>
                                            	<div class="col">
                                                	<div class="form-group">
                                                	    <label for="uname">Financial Year <span class="text-danger">*</span> :</label>
                                                	    <div class="input-group mb-3 flex-nowrap">
                                                	        <select class="form-control select2-show-search" id="financial_id" name="financial_id" data-placeholder="Choose one (with searchbox)">
																<optgroup>
																	@if(isset($financial))
																	@foreach ($financial as $val)
																	<option value="{{ $val->id }}">{{ $val->financial_year }}</option>	
																	@endforeach
																	
																@endif
																</optgroup>
															</select>
                                                	        <div class="input-group-append">
                                                	          <a href="{{url('financial-year-master')}}" class="btn btn-light" type="submit"><i class="fa fa-plus text-success"></i></a>
                                                	        </div>
                                                	    </div>
                                                	</div>
                                            	</div>
                                            </div>
                                        
							    		</div>
							    	</div>
							    </div>
						    </div>
</div>
<div class="card">
    <div class="card-header">
        <h5 class="mb-0"><i class="fa fa-sign-in-alt"></i> Add Inward Entry</h5>
    </div>

    <div class="card-body">
        <div class="row mb-3">
        

        <hr>

        <div class="row">
            {{-- Inward No --}}
            <div class="col-md-4">
                <label>Inward No <span class="text-danger">*</span></label>
                <input type="text" name="inward_no" id="inward_no" class="form-control">
            </div>

            {{-- Received Date --}}
            <div class="col-md-4">
                <label>Received Date <span class="text-danger">*</span></label>
                <input type="date" name="received_date" id="received_date" class="form-control">
            </div>

            {{-- Reference --}}
            <div class="col-md-4">
                <label>Reference</label>
                <input type="text" name="reference" id="reference" class="form-control">
            </div>

            {{-- Invoice Status --}}
            <div class="col-md-4 mt-2">
                <label>Invoice Status</label>
                <select name="invoice_status" id="invoice_status" class="form-control">
                    <option value="">Select</option>
                </select>
            </div>

            {{-- Client Group --}}
            <div class="col-md-4 mt-2">
                <label>Client Group <span class="text-danger">*</span></label>
                <select class="form-control select2" name="client_group_id" id="client_group_id">
                    <option value="">Select</option>
                </select>
                 <div class="input-group-append">
        <a href="{{url('financial-year-master')}}" class="btn btn-light" type="submit"><i class="fa fa-plus text-success"></i></a>
    </div>
            </div>

            {{-- Client Name --}}
            <div class="col-md-4 mt-2">
                <label>Client Name <span class="text-danger">*</span></label>
                <select class="form-control select2" name="client_id" id="client_id">
                    <option value="">Select</option>
                </select>
                 <div class="input-group-append">
                <a href="{{url('financial-year-master')}}" class="btn btn-light" type="submit"><i class="fa fa-plus text-success"></i></a>
            </div>
            </div>

            {{-- Contact Person --}}
            <div class="col-md-4 mt-2">
                <label>Contact Person</label>
                <select class="form-control" name="contact_person_id" id="contact_person_id">
                    <option value="">Select</option>
                </select>
                 <div class="input-group-append">
                    <a href="{{url('financial-year-master')}}" class="btn btn-light" type="submit"><i class="fa fa-plus text-success"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- Inner Product Entry Card --}}
<div class="card mt-3">
    <div class="card-header">
        <h6 class="mb-0"><i class="fa fa-box"></i> Add Inward Product Details</h6>
    </div>

    {{-- Top Table Header --}}
    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead class="bg-dark text-white">
                <tr>
                    <th>ID</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Serial No.</th>
                    <th>Adaptor</th>
                    <th>Draft Shield</th>
                    <th>In-Use Cover</th>
                    <th>Batteries</th>
                    <th>Pan</th>
                    <th>Pan Support</th>
                    <th>Weighing Pan</th>
                    <th>Calibration Wt</th>
                    <th>Cable</th>
                    <th>Other</th>
                    <th>Other Details</th>
                    <th>Nature of Defect</th>
                    <th>Remark</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>

    <div class="card-body">
        <div class="row">
            {{-- Make --}}
            <div class="col-md-4">
                <label>Make <span class="text-danger">*</span></label>
                <div class="input-group mb-2">
                    <select name="make_id" id="make_id" class="form-control select2">
                        <option value="">Select</option>
                    </select>
    
                </div>
            </div>

            {{-- Model --}}
            <div class="col-md-4">
                <label>Model <span class="text-danger">*</span></label>
                <div class="input-group mb-2">
                    <select name="model_id" id="model_id" class="form-control select2">
                        <option value="">Select</option>
                    </select>
                 
                </div>
            </div>

            {{-- Serial No --}}
            <div class="col-md-4">
                <label>Serial No.</label>
                <input type="text" name="serial_no" id="serial_no" class="form-control mb-2">
            </div>

            {{-- Accessories --}}
            <div class="col-md-12">
                <label>Accessories List</label>
                <div class="card p-2">
                    <div class="row">
                        @php
                            $accessories = ['Adaptor', 'Draft Shield', 'In-Use Cover', 'Batteries', 'Pan', 'Pan Support', 'Weighing Pan', 'Calibration Wt', 'Cable', 'Other'];
                        @endphp
                        @foreach ($accessories as $acc)
                            <div class="col-md-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="accessories[]" value="{{ $acc }}" id="acc_{{ Str::slug($acc) }}">
                                    <label class="form-check-label" for="acc_{{ Str::slug($acc) }}">{{ $acc }}</label>
                                </div>
                            </div>
                        @endforeach
                        <div class="col-md-12 mt-2">
                            <input type="text" name="other_accessories" id="other_accessories" class="form-control" placeholder="Other Accessories Details">
                        </div>
                    </div>
                </div>
            </div>

            {{-- Nature of Defect --}}
            <div class="col-md-6 mt-2">
                <label>Nature of Defect</label>
                <textarea name="defect" id="defect" class="form-control" rows="1"></textarea>
            </div>

            {{-- Remark --}}
            <div class="col-md-6 mt-2">
                <label>Remark</label>
                <textarea name="remark" id="remark" class="form-control" rows="1"></textarea>
            </div>
        </div>

        {{-- Buttons --}}
        <div class="row mt-3">
            <div class="col-md-12 d-flex justify-content-between">
                <button type="button" class="btn btn-dark w-25">Add Item</button>
                <button type="reset" class="btn btn-secondary w-25">Clear Product</button>
            </div>
        </div>
    </div>

    {{-- Bottom Table Header --}}
    <div class="table-responsive">
        <table class="table table-bordered table-striped text-nowrap mb-0">
            <thead class="bg-dark text-white">
                <tr>
                    <th>ID</th>
                    <th>Make</th>
                    <th>Model</th>
                    <th>Serial No.</th>
                    <th>Adaptor</th>
                    <th>Draft Shield</th>
                    <th>In-Use Cover</th>
                    <th>Batteries</th>
                    <th>Pan</th>
                    <th>Pan Support</th>
                    <th>Weighing Pan</th>
                    <th>Calibration Wt</th>
                    <th>Cable</th>
                    <th>Other</th>
                    <th>Other Details</th>
                    <th>Nature of Defect</th>
                    <th>Remark</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
@endsection
